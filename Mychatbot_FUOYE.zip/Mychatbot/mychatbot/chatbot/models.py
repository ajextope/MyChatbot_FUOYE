

# Create your models here.
# models.py

from django.db import models
from django.conf import settings
from django.contrib.auth.models import AbstractUser,Group, Permission
from django.utils import timezone


class CustomUser(AbstractUser):
    # Add any additional fields if needed
    name = models.CharField(max_length=255)
    gender = models.CharField(max_length=10, choices=[('male', 'Male'), ('female', 'Female')])
    email = models.EmailField(unique=True)  # Add an email field
    username = models.CharField(max_length=150, unique=True)
    created_at = models.DateTimeField(default=timezone.now)
     # Add a username field
    groups = models.ManyToManyField(
            Group,
            verbose_name=('groups'),
            blank=True,
            help_text=(
                'The groups this user belongs to. '
                'A user will get all permissions granted to each of their groups.'
            ),
            related_name='custom_user_set',  # Change this related_name
            related_query_name='custom_user',
            )
    user_permissions = models.ManyToManyField(
            Permission,
            verbose_name=('user permissions'),
            blank=True,
            help_text=('Specific permissions for this user.'),
            related_name='custom_user_set',  # Change this related_name
            related_query_name='custom_user',
        )

    def __str__(self):
            return self.username

class Message(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    text = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    
class ChatSession(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    start_time = models.DateTimeField(auto_now_add=True)
    end_time = models.DateTimeField(null=True, blank=True)

class Intent(models.Model):
    name = models.CharField(max_length=255)
    keywords = models.TextField()

class Entity(models.Model):
    name = models.CharField(max_length=255)
    value = models.TextField()
    intent = models.ForeignKey(Intent, on_delete=models.CASCADE)

class UserMessage(models.Model):
    message = models.TextField()
    intent = models.ForeignKey(Intent, on_delete=models.SET_NULL, null=True)
    entities = models.ManyToManyField(Entity, blank=True)

class Response(models.Model):
    message = models.TextField()
    intent = models.ForeignKey(Intent, on_delete=models.CASCADE)
