
# Create your views here.
from django.contrib import messages
from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm
from .forms import CustomUserCreationForm
from django.contrib.auth import authenticate, login as auth_login, logout 
from .forms import LoginForm

def Welcome(request): 
    return render(request, 'chatbot/welcome.html')



def signup(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')  # Redirect to login page after successful signup
    else:
        form = CustomUserCreationForm()
    return render(request, 'chatbot/registration/signup.html', {'form': form})




def login_view(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            print(f"Trying to authenticate user: {username}")
            user = authenticate(request, username=username, password=password)
            
            if user is not None:
                print("Authentication successful")
                auth_login(request, user)
                return redirect('home')  # Redirect to the home page or another page of your choice
            else:
                print("Authentication failed")
                messages.error(request, 'Invalid username or password.')
        else:
            messages.error(request, 'Please correct the error below.')
    else:
        form = LoginForm()
    
    return render(request, 'chatbot/registration/login.html', {'form': form})