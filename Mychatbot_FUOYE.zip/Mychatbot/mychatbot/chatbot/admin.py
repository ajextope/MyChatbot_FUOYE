from django.contrib import admin

from .models import CustomUser, Message, ChatSession, Intent, Entity, UserMessage, Response
from .models import Message
# Register your models here.



class MessageAdmin(admin.ModelAdmin):
    list_display = ('user', 'text', 'created_at')
    search_fields = ('text',)
    
    
admin.site.register(CustomUser)
admin.site.register(Message, MessageAdmin)
admin.site.register(ChatSession)
admin.site.register(Intent)
admin.site.register(Entity)
admin.site.register(UserMessage)
admin.site.register(Response)




