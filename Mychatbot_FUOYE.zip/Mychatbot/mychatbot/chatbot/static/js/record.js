document.addEventListener("DOMContentLoaded", function () {
  let form = document.querySelector("form");
  let startButton = document.getElementById("startRecording");
  let stopButton = document.getElementById("stopRecording");
  let recordingStatus = document.getElementById("recordingStatus");
  let audioPlayback = document.getElementById("audioPlayback");
  let audioDataInput = document.getElementById("audioData"); // Hidden file input

  let mediaRecorder;
  let audioChunks = [];

  startButton.onclick = function () {
    navigator.mediaDevices.getUserMedia({ audio: true }).then((stream) => {
      mediaRecorder = new MediaRecorder(stream);
      mediaRecorder.start();

      mediaRecorder.ondataavailable = function (e) {
        audioChunks.push(e.data);
      };

      startButton.disabled = true;
      stopButton.disabled = false;
    });
  };

  stopButton.onclick = function () {
    mediaRecorder.stop();
    startButton.disabled = false;
    stopButton.disabled = true;

    mediaRecorder.onstop = function () {
      const audioBlob = new Blob(audioChunks, { type: "audio/wav" });
      const audioUrl = URL.createObjectURL(audioBlob);
      audioPlayback.src = audioUrl;

      // Show the recording status and playback controls
      recordingStatus.style.display = "block";

      // Prepare the recorded audio for form submission
      audioDataInput.files = createFileList(audioBlob);

      // Clear the chunks for the next recording
      audioChunks = [];
    };
  };

  // Utility function to convert Blob to FileList
  function createFileList(...files) {
    const dataTransfer = new DataTransfer();
    files.forEach((file) => {
      const fileInput = new File([file], "recording.wav", {
        type: "audio/wav",
      });
      dataTransfer.items.add(fileInput);
    });
    return dataTransfer.files;
  }
});
